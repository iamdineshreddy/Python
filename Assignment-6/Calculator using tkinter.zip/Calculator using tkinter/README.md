# ASSIGNMENT 6 – Calculator Using Tkinter  
Module 14 & 15: Python GUI Programming

## 📌 Project Overview
This project is a **Calculator application developed using Python’s Tkinter library**.  
It is created as part of **Assignment 6** for **Module 14 & 15**, focusing on GUI development, event handling, and error management.

The calculator performs basic arithmetic operations and includes proper input validation and error handling.

---

## 🧮 Features
- Addition (+)
- Subtraction (−)
- Multiplication (×)
- Division (÷)
- Clear input functionality
- Error handling for invalid expressions
- Division by zero handling
- User-friendly graphical interface

---

## 📂 Project Structure

Calculator_Tkinter_Project/
│
├── calculator.py
└── README.md

yaml
Copy code

---

## ▶️ How to Run the Project

1. Ensure **Python 3.x** is installed on your system.
2. Download or clone the project folder.
3. Open Command Prompt / Terminal.
4. Navigate to the project directory.
5. Run the following command:
   ```bash
   python calculator.py